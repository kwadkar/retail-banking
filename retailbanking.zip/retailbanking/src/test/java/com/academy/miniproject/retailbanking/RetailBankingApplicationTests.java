package com.academy.miniproject.retailbanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
