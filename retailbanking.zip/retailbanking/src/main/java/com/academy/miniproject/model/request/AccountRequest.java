package com.academy.miniproject.model.request;

import lombok.Data;

@Data
public class AccountRequest {

	private String accountNumber;
	
	private double balance;
}
