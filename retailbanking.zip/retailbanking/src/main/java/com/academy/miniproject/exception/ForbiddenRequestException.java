package com.academy.miniproject.exception;

public class ForbiddenRequestException extends RuntimeException{
	
	public ForbiddenRequestException(String message) {
		super(message);
	}
	
   


}
