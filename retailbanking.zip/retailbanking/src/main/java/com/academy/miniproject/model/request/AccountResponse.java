package com.academy.miniproject.model.request;

import lombok.Data;

@Data
public class AccountResponse {
	

	private String accountNumber;
	
	private double balance;
}
